// @polsia:user-owned — catalog contract and source-mapping regression tests.
import { describe, expect, it } from 'vitest';
import { brandVisual } from '@/lib/brand';
import { toCatalogProduct } from '@/lib/business/catalog';
import { CatalogCategory, CatalogList } from '@/lib/contracts/catalog';

const sourceRecord = {
  id: 'test-product-1',
  slug: 'supplied-slide',
  name: 'Supplied Slide',
  category: 'footwear',
  description: null,
  imageUrl: null,
  priceInMinorUnits: null,
  currency: null,
  availableSizes: [],
  stockStatus: null,
};

describe('public catalog contracts', () => {
  it('accepts all four public category views and rejects invented categories', () => {
    expect(CatalogCategory.options).toEqual(['footwear', 'handbags', 'socks', 'accessories']);
    expect(CatalogCategory.safeParse('jewellery').success).toBe(false);
  });

  it('maps one canonical source record for both list and detail responses', () => {
    const item = toCatalogProduct(sourceRecord);
    expect(CatalogList.parse({ items: [item] }).items[0]).toEqual(item);
    expect(item).toMatchObject({
      id: sourceRecord.id,
      slug: sourceRecord.slug,
      name: sourceRecord.name,
      imageUrl: null,
      priceInMinorUnits: null,
      availableSizes: [],
      stockStatus: null,
    });
  });

  it('keeps missing source fields missing instead of supplying defaults', () => {
    const item = toCatalogProduct(sourceRecord);
    expect(item.imageUrl).toBeNull();
    expect(item.priceInMinorUnits).toBeNull();
    expect(item.currency).toBeNull();
    expect(item.availableSizes).toEqual([]);
    expect(item.stockStatus).toBeNull();
  });

  it('keeps the generated photographic OG background and Slide Stop colors configured', () => {
    const image = new URL(brandVisual.og.image);
    expect(image.protocol).toBe('https:');
    expect(image.hostname).toBe('cdn.polsia.com');
    expect(brandVisual.og.background).toBe('#2d1710');
    expect(brandVisual.og.foreground).toBe('#fff7ed');
    expect(brandVisual.og.tagline).toContain('Ghana');
  });
});

import { expect, test } from '@playwright/test';

test.describe('public Slide Stop catalog', () => {
  test('homepage links visitors to every public category view', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Slide Stop.' })).toBeVisible();
    for (const category of ['Footwear', 'Handbags', 'Socks', 'Accessories']) {
      await expect(page.locator(`a[href="/catalog/${category.toLowerCase()}"]`).first()).toBeVisible();
    }
    await page.locator('a[href="/catalog/footwear"]').first().click();
    await expect(page).toHaveURL(/\/catalog\/footwear$/);
    await expect(page.getByRole('heading', { name: 'Footwear' })).toBeVisible();
    await expect(page.getByText('No supplied products yet.')).toBeVisible();
    await page.screenshot();
  });

  test('empty source data stays truthful and public API has no mutation route', async ({ page }) => {
    await page.goto('/');
    const apiChecks = await page.evaluate(async () => {
      const list = await fetch('/api/catalog?category=footwear');
      const mutation = await fetch('/api/catalog', { method: 'POST', body: '{}' });
      return {
        listStatus: list.status,
        listBody: await list.json(),
        mutationStatus: mutation.status,
      };
    });
    expect(apiChecks.listStatus).toBe(200);
    expect(apiChecks.listBody).toEqual({ items: [] });
    expect(apiChecks.mutationStatus).toBe(405);

    await page.goto('/catalog/product/not-supplied');
    await expect(page.getByRole('heading', { name: 'Product details unavailable' })).toBeVisible();
    await expect(page.getByText(/no product information has been invented/i)).toBeVisible();
    await page.screenshot();
  });
});

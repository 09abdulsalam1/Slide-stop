// @polsia:user-owned — public catalog composition and source-to-API mapping.
import { type CatalogCategory, CatalogProduct } from '@/lib/contracts/catalog';

export const catalogCategories = [
  {
    slug: 'footwear',
    label: 'Footwear',
    description: 'Slides, sandals, sneakers, and other steps.',
  },
  {
    slug: 'handbags',
    label: 'Handbags',
    description: 'Bags for the everyday edit.',
  },
  {
    slug: 'socks',
    label: 'Socks',
    description: 'The finishing layer for every pair.',
  },
  {
    slug: 'accessories',
    label: 'Accessories',
    description: 'Small details that complete the look.',
  },
] as const satisfies ReadonlyArray<{
  slug: CatalogCategory;
  label: string;
  description: string;
}>;

export type CatalogSourceRecord = {
  id: string;
  slug: string;
  name: string;
  category: string;
  description: string | null;
  imageUrl: string | null;
  priceInMinorUnits: number | null;
  currency: string | null;
  availableSizes: string[];
  availableColors?: string[];
  stockQuantity?: number;
  discountPercent?: number;
  salePriceInMinorUnits?: number | null;
  stockStatus: string | null;
};

export function toCatalogProduct(record: CatalogSourceRecord) {
  return CatalogProduct.parse({
    id: record.id,
    slug: record.slug,
    name: record.name,
    category: record.category,
    description: record.description,
    imageUrl: record.imageUrl,
    priceInMinorUnits: record.priceInMinorUnits,
    currency: record.currency,
    availableSizes: record.availableSizes,
    availableColors: record.availableColors ?? [],
    stockQuantity: record.stockQuantity ?? 0,
    discountPercent: record.discountPercent ?? 0,
    salePriceInMinorUnits: record.salePriceInMinorUnits ?? null,
    stockStatus: record.stockStatus,
  });
}

import type { CatalogProduct } from '@/lib/contracts/catalog';

export type CartLine = { product: CatalogProduct; quantity: number; size: string };
export const CART_STORAGE_KEY = 'Slide Stop-cart-v1';
export function formatGhs(minorUnits: number | null, currency: string | null) {
  if (minorUnits === null || !currency) return 'Price unavailable';
  try { return new Intl.NumberFormat('en-GH', { style: 'currency', currency, maximumFractionDigits: 2 }).format(minorUnits / 100); }
  catch { return 'Price unavailable'; }
}
export function orderMessage(lines: CartLine[], customer: { name: string; phone: string; address: string; notes: string }) {
  const products = lines.map((line) => { const base = line.product.priceInMinorUnits; const unit = base === null ? null : (line.product.salePriceInMinorUnits ?? (line.product.discountPercent > 0 ? Math.round(base * (100 - line.product.discountPercent) / 100) : base)); return `• ${line.product.name}${line.size ? ` (Size: ${line.size})` : ''} × ${line.quantity} — ${formatGhs(unit === null ? null : unit * line.quantity, line.product.currency)}`; }).join('\n');
  return `Hello Slide Stop! I'd like to place a cash-on-delivery order.\n\n${products}\n\nCustomer: ${customer.name}\nPhone: ${customer.phone}\nDelivery address: ${customer.address}\nPayment: Pay on delivery${customer.notes ? `\nNotes: ${customer.notes}` : ''}\n\nPlease confirm product availability, delivery fee, and total before dispatch.`;
}

// @polsia:user-owned — brand identity. Edit freely. `site.ts` re-exports
// siteName/siteDescription; `manifest.ts` + `opengraph-image.tsx` read `brandVisual`.

export const siteName = 'Slide Stop';
export const siteDescription = 'Trendy steps and accessories, delivered across Ghana.';

// PWA + social-share colors. HEX only (CSS variables aren't readable here) — set
// them to match the theme you define in src/app/brand-theme.css. The starter
// values are achromatic placeholders, not a palette.
export const brandVisual = {
  /** PWA browser-UI / status-bar color — usually your background or primary. */
  themeColor: '#c7653e',
  /** PWA splash + install background. */
  backgroundColor: '#fbf7f1',
  /** Social-share (OG/Twitter) image. */
  og: {
    background: '#2d1710',
    foreground: '#fff7ed',
    /** Second line under the site name; '' hides it. */
    tagline: 'Trendy steps and accessories, delivered across Ghana.',
    /** Optional https PNG/JPEG background photo; '' keeps the plain-color card. */
    image:
      'https://cdn.polsia.com/generated-images/company_826130/1fb64de7-5aa9-40f6-9916-f67dec2ec1e4.jpg',
  },
} as const;

// @polsia:user-owned — shared read contract for the public catalog API.
// Keep this module client-safe: zod only, no database or server imports.
import { z } from 'zod';

export const CatalogCategory = z.enum(['footwear', 'handbags', 'socks', 'accessories']);

export const CatalogProduct = z.object({
  id: z.string(),
  slug: z.string(),
  name: z.string(),
  category: z.string(),
  description: z.string().nullable(),
  imageUrl: z.string().nullable(),
  priceInMinorUnits: z.number().int().nullable(),
  currency: z.string().nullable(),
  availableSizes: z.array(z.string()),
  availableColors: z.array(z.string()).optional().default([]),
  stockQuantity: z.number().int().optional().default(0),
  discountPercent: z.number().int().optional().default(0),
  salePriceInMinorUnits: z.number().int().nullable().optional().default(null),
  stockStatus: z.string().nullable(),
});

export const CatalogList = z.object({ items: z.array(CatalogProduct) });
export const CatalogProductResponse = z.object({ item: CatalogProduct });

export type CatalogCategory = z.infer<typeof CatalogCategory>;
export type CatalogProduct = z.infer<typeof CatalogProduct>;
export type CatalogList = z.infer<typeof CatalogList>;
export type CatalogProductResponse = z.infer<typeof CatalogProductResponse>;

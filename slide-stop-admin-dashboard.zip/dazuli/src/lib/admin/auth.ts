import 'server-only';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { cookies } from 'next/headers';

const COOKIE = 'Slide Stop_admin_session';
const TTL_SECONDS = 60 * 60 * 8;
function secret() {
  const value = process.env.ADMIN_SESSION_SECRET;
  if (!value || value.length < 32) throw new Error('ADMIN_SESSION_SECRET must be at least 32 characters');
  return value;
}
function signature(payload: string) { return createHmac('sha256', secret()).update(payload).digest('base64url'); }
export function validAdminPassword(password: string) {
  const expected = process.env.Slide Stop_ADMIN_PASSWORD;
  if (!expected || expected.length < 12) throw new Error('Slide Stop_ADMIN_PASSWORD must be at least 12 characters');
  const a = Buffer.from(password); const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}
export function createSessionToken() {
  const payload = `${Date.now() + TTL_SECONDS * 1000}`;
  return `${payload}.${signature(payload)}`;
}
export function verifySessionToken(token?: string) {
  if (!token) return false;
  const [expires, sig, extra] = token.split('.');
  if (!expires || !sig || extra || !/^\d+$/.test(expires) || Number(expires) < Date.now()) return false;
  try {
    const expected = Buffer.from(signature(expires)); const actual = Buffer.from(sig);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch { return false; }
}
export async function isAdminRequest() {
  const jar = await cookies();
  return verifySessionToken(jar.get(COOKIE)?.value);
}
export const adminCookieOptions = { name: COOKIE, httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict' as const, path: '/', maxAge: TTL_SECONDS };

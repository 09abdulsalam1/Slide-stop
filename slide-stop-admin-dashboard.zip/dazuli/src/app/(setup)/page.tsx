// @polsia:user-owned — configure the public Slide Stop home page here.

import {
  ArrowDownRight,
  ArrowUpRight,
  Footprints,
  MapPinned,
  ShieldCheck,
  ShoppingBag,
  ShoppingBasket,
  Sparkles,
  Truck,
} from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import type { ReactNode } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { siteDescription, siteName } from '@/lib/brand';

export const metadata: Metadata = {
  title: { absolute: siteName },
  description: siteDescription,
  alternates: { canonical: '/' },
};

const contactHref = 'mailto:Slide Stop@polsia.app';

const catalogLinks = [
  { label: 'Footwear', href: '/catalog/footwear', description: 'Slides, sandals, and sneakers.' },
  { label: 'Handbags', href: '/catalog/handbags', description: 'Bags for the everyday edit.' },
  { label: 'Socks', href: '/catalog/socks', description: 'The finishing layer for every pair.' },
  {
    label: 'Accessories',
    href: '/catalog/accessories',
    description: 'Small details that complete the look.',
  },
] as const;

function ShoeMark({ className = '' }: { className?: string }) {
  return (
    <svg
      aria-hidden="true"
      className={className}
      viewBox="0 0 320 180"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M61 35c16 2 39 18 59 39 17 18 42 27 79 34 33 6 68 16 78 31 7 11-1 20-17 23H67c-27 0-46-15-46-34 0-17 10-31 26-43 13-10 18-25 14-42Z"
        fill="currentColor"
      />
      <path
        d="M61 35c16 2 39 18 59 39 17 18 42 27 79 34 33 6 68 16 78 31"
        stroke="currentColor"
        strokeWidth="8"
        strokeLinecap="round"
      />
      <path
        d="M105 64c18 18 41 27 68 32M81 91c22 14 47 22 75 26"
        stroke="currentColor"
        strokeWidth="12"
        strokeLinecap="round"
        opacity="0.42"
      />
    </svg>
  );
}

function ArrowLink({
  children,
  href,
  inverted = false,
}: {
  children: ReactNode;
  href: string;
  inverted?: boolean;
}) {
  return (
    <Link
      href={href}
      className={`group inline-flex items-center gap-2 text-sm font-semibold transition-colors duration-200 ease-out ${inverted ? 'text-primary-foreground hover:text-primary-foreground/80' : 'text-foreground hover:text-primary'}`}
    >
      {children}
      <ArrowUpRight className="size-4 transition-transform duration-200 ease-out group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
    </Link>
  );
}

export default function HomePage() {
  return (
    <main className="overflow-hidden">
      <section
        id="home"
        aria-labelledby="hero-heading"
        className="relative isolate border-b border-border"
      >
        <div
          aria-hidden="true"
          className="absolute -right-24 top-8 -z-10 size-72 rounded-full bg-primary/10 blur-3xl sm:size-96"
        />
        <div className="mx-auto grid min-h-[calc(100svh-4.5rem)] max-w-7xl items-center gap-12 px-6 py-16 sm:px-10 lg:grid-cols-[1.02fr_.98fr] lg:gap-16 lg:px-12 lg:py-20">
          <div className="max-w-2xl animate-in fade-in slide-in-from-bottom-3 duration-700">
            <Badge
              variant="outline"
              className="mb-7 gap-2 rounded-full px-3 py-1 text-[0.68rem] uppercase tracking-[0.18em]"
            >
              <span className="size-1.5 rounded-full bg-primary" aria-hidden="true" />
              Online fashion store · Ghana
            </Badge>
            <h1
              id="hero-heading"
              className="max-w-3xl font-display text-6xl leading-[0.92] tracking-[-0.06em] text-foreground sm:text-7xl lg:text-8xl"
            >
              Slide Stop.
              <span className="mt-3 block text-primary">Step into what&apos;s next.</span>
            </h1>
            <p className="mt-8 max-w-xl text-lg leading-8 text-muted-foreground sm:text-xl">
              Trendy steps and accessories, delivered across Ghana. Find the pair, bag, or everyday
              extra that makes the whole look click.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button
                asChild
                size="lg"
                className="h-12 rounded-full px-6 transition-transform duration-200 ease-out hover:-translate-y-0.5"
              >
                <Link href="#collection">
                  Explore the collection
                  <ArrowDownRight />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-12 rounded-full px-6">
                <Link href={contactHref}>Start an order</Link>
              </Button>
            </div>
            <div className="mt-12 flex max-w-md items-start gap-3 border-l-2 border-primary pl-4 text-sm leading-6 text-muted-foreground">
              <MapPinned className="mt-1 size-4 shrink-0 text-primary" aria-hidden="true" />
              <p>Easy online ordering with reliable delivery wherever you are in Ghana.</p>
            </div>
          </div>

          <div
            role="img"
            className="relative mx-auto w-full max-w-xl lg:justify-self-end"
            aria-label="A curated selection of Slide Stop footwear and accessories"
          >
            <div className="relative aspect-[0.92] overflow-hidden rounded-[2rem] border border-border bg-muted p-5 shadow-2xl sm:p-8">
              <div
                className="absolute inset-0 bg-[radial-gradient(circle_at_75%_18%,hsl(var(--primary)/.18),transparent_32%),linear-gradient(145deg,transparent_0%,hsl(var(--background)/.3)_100%)]"
                aria-hidden="true"
              />
              <div className="relative flex h-full flex-col justify-between">
                <div className="flex items-start justify-between">
                  <p className="font-display text-2xl tracking-tight text-foreground">
                    The everyday edit
                  </p>
                  <span className="grid size-11 place-items-center rounded-full bg-primary text-primary-foreground">
                    <ShoppingBag className="size-5" aria-hidden="true" />
                  </span>
                </div>
                <div className="relative mx-auto aspect-square w-[88%]">
                  <div className="absolute left-[12%] top-[9%] h-[58%] w-[57%] rotate-[-13deg] rounded-[45%_45%_18%_22%] bg-primary shadow-xl transition-transform duration-500 ease-out hover:rotate-[-8deg] hover:scale-105">
                    <div className="absolute inset-x-[16%] top-[18%] h-[18%] rounded-full bg-primary-foreground/25" />
                    <div className="absolute bottom-[7%] left-[9%] right-[9%] h-[12%] rounded-full bg-primary-foreground/25" />
                  </div>
                  <div className="absolute bottom-[3%] right-[2%] h-[52%] w-[60%] rotate-[12deg] rounded-[48%_42%_20%_18%] bg-accent shadow-xl transition-transform duration-500 ease-out hover:rotate-[7deg] hover:scale-105">
                    <div className="absolute left-[14%] top-[17%] h-[18%] w-[48%] rounded-full bg-accent-foreground/20" />
                    <div className="absolute bottom-[8%] left-[10%] right-[8%] h-[12%] rounded-full bg-accent-foreground/20" />
                  </div>
                  <ShoeMark className="absolute -bottom-1 left-0 w-[92%] -rotate-12 text-secondary-foreground/80" />
                  <div className="absolute right-0 top-[11%] grid size-16 place-items-center rounded-full border border-border bg-card text-center shadow-lg sm:size-20">
                    <span className="font-display text-xl leading-none text-foreground">01</span>
                  </div>
                </div>
                <div className="flex items-end justify-between gap-4 border-t border-border pt-4">
                  <div>
                    <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">
                      Curated for now
                    </p>
                    <p className="mt-1 font-display text-xl text-foreground">Wear it your way.</p>
                  </div>
                  <Sparkles className="size-6 text-primary" aria-hidden="true" />
                </div>
              </div>
            </div>
            <p className="mt-4 text-right text-xs uppercase tracking-[0.16em] text-muted-foreground">
              Footwear · bags · extras
            </p>
          </div>
        </div>
      </section>

      <section
        id="collection"
        aria-labelledby="collection-heading"
        className="mx-auto max-w-7xl px-6 py-24 sm:px-10 lg:px-12 lg:py-32"
      >
        <div className="mb-14 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-xl">
            <p className="mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
              Shop the mood
            </p>
            <h2
              id="collection-heading"
              className="font-display text-4xl leading-tight tracking-[-0.05em] sm:text-6xl"
            >
              Find your next favorite pair.
            </h2>
          </div>
          <p className="max-w-sm text-base leading-7 text-muted-foreground">
            A focused mix of current styles and dependable everyday pieces, chosen to make getting
            dressed feel easy.
          </p>
        </div>
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-12">
          <Card className="group overflow-hidden rounded-3xl border-primary bg-primary text-primary-foreground shadow-none transition-transform duration-300 ease-out hover:-translate-y-1 lg:col-span-7">
            <CardContent className="relative flex min-h-[24rem] flex-col justify-between p-7 sm:p-10">
              <div className="relative z-10 flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground/70">
                    01 / The easy pair
                  </p>
                  <h3 className="mt-4 max-w-sm font-display text-4xl leading-none tracking-[-0.05em] sm:text-5xl">
                    Slides &amp; sandals for every plan.
                  </h3>
                </div>
                <Footprints className="size-7 shrink-0" aria-hidden="true" />
              </div>
              <div className="relative z-10 mt-16 flex items-end justify-between gap-4">
                <p className="max-w-xs text-sm leading-6 text-primary-foreground/75">
                  Birkenstock-style comfort, women&apos;s and men&apos;s slides, and fashion sandals
                  with a little more attitude.
                </p>
                <ArrowLink href="/catalog/footwear" inverted>
                  Browse footwear
                </ArrowLink>
              </div>
              <ShoeMark className="absolute -bottom-7 -right-16 w-[75%] rotate-[-12deg] text-primary-foreground/10 transition-transform duration-500 ease-out group-hover:rotate-[-7deg] group-hover:scale-105" />
            </CardContent>
          </Card>
          <Card className="group overflow-hidden rounded-3xl border-border bg-muted shadow-none transition-transform duration-300 ease-out hover:-translate-y-1 lg:col-span-5">
            <CardContent className="flex min-h-[24rem] flex-col justify-between p-7 sm:p-10">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
                    02 / The finishing touch
                  </p>
                  <h3 className="mt-4 max-w-xs font-display text-4xl leading-none tracking-[-0.05em] sm:text-5xl">
                    Bags, socks &amp; extras.
                  </h3>
                </div>
                <ShoppingBasket className="size-7 text-primary" aria-hidden="true" />
              </div>
              <div>
                <div className="mb-7 flex items-center gap-2 text-primary">
                  <span className="h-px w-10 bg-primary" />
                  <span className="text-xs uppercase tracking-[0.16em]">
                    Small details, big lift
                  </span>
                </div>
                <ArrowLink href="/catalog/handbags">Browse handbags</ArrowLink>
              </div>
            </CardContent>
          </Card>
          <Card className="rounded-3xl border-border bg-card shadow-none lg:col-span-4">
            <CardContent className="flex min-h-52 flex-col justify-between p-7">
              <Sparkles className="size-6 text-primary" aria-hidden="true" />
              <div>
                <h3 className="font-display text-3xl tracking-[-0.04em]">Sneakers</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  For days that need a little more pace.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card className="rounded-3xl border-border bg-card shadow-none lg:col-span-4">
            <CardContent className="flex min-h-52 flex-col justify-between p-7">
              <ShieldCheck className="size-6 text-primary" aria-hidden="true" />
              <div>
                <h3 className="font-display text-3xl tracking-[-0.04em]">Quality picks</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Styles selected for real, repeat wear.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card className="rounded-3xl border-border bg-card shadow-none lg:col-span-4">
            <CardContent className="flex min-h-52 flex-col justify-between p-7">
              <ShoppingBag className="size-6 text-primary" aria-hidden="true" />
              <div>
                <h3 className="font-display text-3xl tracking-[-0.04em]">Affordable style</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">
                  Current looks at accessible prices.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="mt-8 rounded-3xl border border-border bg-card p-7 sm:p-10">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
                Browse the catalog
              </p>
              <h3 className="mt-3 font-display text-3xl tracking-[-0.04em] sm:text-4xl">
                Start with a category.
              </h3>
            </div>
            <Link
              href="/catalog"
              className="inline-flex items-center gap-2 text-sm font-semibold text-primary"
            >
              View all supplied products <ArrowUpRight className="size-4" aria-hidden="true" />
            </Link>
          </div>
          <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {catalogLinks.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="group rounded-2xl border border-border p-5 transition-colors hover:border-primary hover:bg-muted"
              >
                <span className="flex items-center justify-between font-display text-xl tracking-[-0.03em]">
                  {item.label}
                  <ArrowUpRight
                    className="size-4 text-primary transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                    aria-hidden="true"
                  />
                </span>
                <span className="mt-2 block text-sm leading-6 text-muted-foreground">
                  {item.description}
                </span>
              </Link>
            ))}
          </div>
          <p className="mt-6 text-sm leading-6 text-muted-foreground">
            Only product records supplied to Slide Stop appear in the catalog. Missing details are
            labeled unavailable.
          </p>
        </div>
      </section>

      <section
        id="values"
        aria-labelledby="values-heading"
        className="border-y border-border bg-muted/40"
      >
        <div className="mx-auto grid max-w-7xl gap-14 px-6 py-24 sm:px-10 lg:grid-cols-[.8fr_1.2fr] lg:gap-24 lg:px-12 lg:py-32">
          <div className="lg:sticky lg:top-24 lg:self-start">
            <p className="mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
              Why Slide Stop
            </p>
            <h2
              id="values-heading"
              className="max-w-md font-display text-4xl leading-tight tracking-[-0.05em] sm:text-6xl"
            >
              Style should be easy to say yes to.
            </h2>
            <p className="mt-6 max-w-sm text-base leading-7 text-muted-foreground">
              Slide Stop brings the fun of finding a fresh look together with the confidence of a
              straightforward order.
            </p>
          </div>
          <div className="divide-y divide-border border-y border-border">
            <div className="grid gap-4 py-8 sm:grid-cols-[5rem_1fr] sm:gap-8">
              <span className="font-display text-3xl text-primary">01</span>
              <div>
                <h3 className="font-display text-3xl tracking-[-0.04em]">
                  Current, not complicated.
                </h3>
                <p className="mt-3 max-w-lg leading-7 text-muted-foreground">
                  From relaxed slides to standout sandals, the collection keeps an eye on what is
                  trending while staying easy to wear.
                </p>
              </div>
            </div>
            <div className="grid gap-4 py-8 sm:grid-cols-[5rem_1fr] sm:gap-8">
              <span className="font-display text-3xl text-primary">02</span>
              <div>
                <h3 className="font-display text-3xl tracking-[-0.04em]">
                  Quality that meets real life.
                </h3>
                <p className="mt-3 max-w-lg leading-7 text-muted-foreground">
                  We focus on pieces that look good, feel good, and earn their place in your
                  everyday rotation.
                </p>
              </div>
            </div>
            <div className="grid gap-4 py-8 sm:grid-cols-[5rem_1fr] sm:gap-8">
              <span className="font-display text-3xl text-primary">03</span>
              <div>
                <h3 className="font-display text-3xl tracking-[-0.04em]">Made to reach you.</h3>
                <p className="mt-3 max-w-lg leading-7 text-muted-foreground">
                  Convenient online ordering and reliable delivery across Ghana keep your next
                  favorite close, wherever you are.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section
        id="delivery"
        aria-labelledby="delivery-heading"
        className="mx-auto max-w-7xl px-6 py-24 sm:px-10 lg:px-12 lg:py-32"
      >
        <div className="mb-14 max-w-xl">
          <p className="mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
            From browse to doorstep
          </p>
          <h2
            id="delivery-heading"
            className="font-display text-4xl leading-tight tracking-[-0.05em] sm:text-6xl"
          >
            A simple way to find your fit.
          </h2>
        </div>
        <div className="grid gap-0 border-y border-border md:grid-cols-3">
          {[
            {
              number: '01',
              icon: ShoppingBag,
              title: 'Pick your pair',
              description:
                'Tell us what caught your eye, from everyday slides to a full accessories refresh.',
            },
            {
              number: '02',
              icon: Sparkles,
              title: 'Make it yours',
              description:
                'We help you choose the style and details that feel right for your wardrobe.',
            },
            {
              number: '03',
              icon: Truck,
              title: 'We get it moving',
              description: 'Place your order online and count on reliable delivery across Ghana.',
            },
          ].map(({ number, icon: Icon, title, description }, index) => (
            <div
              key={number}
              className={`relative py-8 md:px-8 md:py-10 ${index > 0 ? 'border-t border-border md:border-l md:border-t-0' : ''}`}
            >
              <div className="flex items-center justify-between">
                <span className="font-display text-3xl text-primary">{number}</span>
                <Icon className="size-5 text-primary" aria-hidden="true" />
              </div>
              <h3 className="mt-12 font-display text-3xl tracking-[-0.04em]">{title}</h3>
              <p className="mt-3 max-w-xs leading-7 text-muted-foreground">{description}</p>
            </div>
          ))}
        </div>
      </section>

      <section
        id="contact"
        aria-labelledby="contact-heading"
        className="px-6 pb-8 sm:px-10 lg:px-12"
      >
        <div className="mx-auto flex max-w-7xl flex-col gap-8 rounded-[2rem] bg-primary px-7 py-12 text-primary-foreground sm:px-12 sm:py-16 lg:flex-row lg:items-end lg:justify-between lg:px-16">
          <div className="max-w-2xl">
            <p className="mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground/70">
              Your next pair is closer than you think
            </p>
            <h2
              id="contact-heading"
              className="font-display text-5xl leading-[0.95] tracking-[-0.06em] sm:text-7xl"
            >
              Ready to step into style?
            </h2>
            <p className="mt-6 max-w-lg text-base leading-7 text-primary-foreground/75">
              Tell us what you are looking for and we&apos;ll help you start your Slide Stop order.
            </p>
          </div>
          <Button
            asChild
            size="lg"
            variant="secondary"
            className="h-12 shrink-0 rounded-full px-6 text-secondary-foreground transition-transform duration-200 ease-out hover:-translate-y-0.5"
          >
            <Link href={contactHref}>
              Email Slide Stop@polsia.app
              <ArrowUpRight />
            </Link>
          </Button>
        </div>
      </section>
    </main>
  );
}

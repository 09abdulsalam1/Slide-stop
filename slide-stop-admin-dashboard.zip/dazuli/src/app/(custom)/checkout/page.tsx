import type { Metadata } from 'next';
import { CheckoutForm } from '@/components/custom/checkout-form';

export const metadata: Metadata = {
  title: 'Checkout',
  description: 'Place your Slide Stop order with cash on delivery in Ghana.',
  alternates: { canonical: '/checkout' },
};

export default function CheckoutPage() {
  return <main className="mx-auto max-w-7xl px-5 py-10 sm:px-8 sm:py-16"><CheckoutForm /></main>;
}

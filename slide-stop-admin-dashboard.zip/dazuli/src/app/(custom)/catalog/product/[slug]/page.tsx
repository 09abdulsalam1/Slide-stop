// @polsia:user-owned — public product detail view.
import type { Metadata } from 'next';
import { CatalogProductDetail } from '@/components/custom/catalog-product-detail';

export const metadata: Metadata = {
  title: 'Product details',
  description: 'Product details supplied by Slide Stop.',
};

export default async function CatalogProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  return (
    <main className="mx-auto max-w-7xl px-6 py-16 sm:px-10 lg:px-12 lg:py-24">
      <CatalogProductDetail slug={slug} />
    </main>
  );
}

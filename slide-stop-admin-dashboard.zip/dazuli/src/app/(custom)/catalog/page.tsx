// @polsia:user-owned — public catalog index.
import { ArrowUpRight } from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { CatalogBrowser } from '@/components/custom/catalog-browser';
import { catalogCategories } from '@/lib/business/catalog';

export const metadata: Metadata = {
  title: 'Catalog',
  description: 'Browse Slide Stop footwear, handbags, socks, and accessories supplied for Ghana.',
  alternates: { canonical: '/catalog' },
};

export default function CatalogPage() {
  return (
    <main className="mx-auto max-w-7xl px-6 py-16 sm:px-10 lg:px-12 lg:py-24">
      <div className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">
          Slide Stop catalog
        </p>
        <h1 className="mt-5 font-display text-5xl leading-[0.95] tracking-[-0.06em] sm:text-7xl">
          Find your next favorite.
        </h1>
        <p className="mt-6 text-lg leading-8 text-muted-foreground">
          Browse the product records supplied by Slide Stop. When a detail is not supplied, we label it
          unavailable.
        </p>
      </div>
      <nav
        aria-label="Catalog categories"
        className="mt-12 flex flex-wrap gap-3 border-y border-border py-5"
      >
        <Link
          href="/catalog"
          className="rounded-full border border-primary bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
        >
          All products
        </Link>
        {catalogCategories.map((category) => (
          <Link
            key={category.slug}
            href={`/catalog/${category.slug}`}
            className="inline-flex items-center gap-1 rounded-full border border-border px-4 py-2 text-sm font-semibold transition-colors hover:border-primary hover:text-primary"
          >
            {category.label} <ArrowUpRight className="size-4" aria-hidden="true" />
          </Link>
        ))}
      </nav>
      <div className="mt-10">
        <CatalogBrowser />
      </div>
    </main>
  );
}

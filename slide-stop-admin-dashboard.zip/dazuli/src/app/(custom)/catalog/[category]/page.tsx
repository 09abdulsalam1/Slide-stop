// @polsia:user-owned — public catalog category view.
import { ArrowLeft, ArrowUpRight } from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { CatalogBrowser } from '@/components/custom/catalog-browser';
import { catalogCategories } from '@/lib/business/catalog';
import { CatalogCategory } from '@/lib/contracts/catalog';

export const metadata: Metadata = {
  title: 'Shop by category',
  description: 'Browse a supplied Slide Stop catalog category.',
};

export default async function CatalogCategoryPage({
  params,
}: {
  params: Promise<{ category: string }>;
}) {
  const { category: value } = await params;
  const category = CatalogCategory.safeParse(value);
  const details = category.success
    ? catalogCategories.find((item) => item.slug === category.data)
    : undefined;

  if (!category.success || !details) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-24 sm:px-10">
        <h1 className="font-display text-5xl tracking-[-0.06em]">Category unavailable</h1>
        <p className="mt-4 leading-7 text-muted-foreground">
          This catalog category is not part of Slide Stop&apos;s public catalog.
        </p>
        <Link
          href="/catalog"
          className="mt-8 inline-flex items-center gap-2 font-semibold text-primary"
        >
          <ArrowLeft className="size-4" /> Back to catalog
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl px-6 py-16 sm:px-10 lg:px-12 lg:py-24">
      <Link
        href="/catalog"
        className="inline-flex items-center gap-2 text-sm font-semibold text-primary"
      >
        <ArrowLeft className="size-4" /> All products
      </Link>
      <div className="mt-10 max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">
          Slide Stop / {details.label}
        </p>
        <h1 className="mt-5 font-display text-5xl leading-[0.95] tracking-[-0.06em] sm:text-7xl">
          {details.label}
        </h1>
        <p className="mt-6 text-lg leading-8 text-muted-foreground">
          {details.description} Only supplied records appear below.
        </p>
      </div>
      <nav
        aria-label="Catalog categories"
        className="mt-12 flex flex-wrap gap-3 border-y border-border py-5"
      >
        {catalogCategories.map((item) => (
          <Link
            key={item.slug}
            href={`/catalog/${item.slug}`}
            className={`inline-flex items-center gap-1 rounded-full border px-4 py-2 text-sm font-semibold transition-colors ${item.slug === details.slug ? 'border-primary bg-primary text-primary-foreground' : 'border-border hover:border-primary hover:text-primary'}`}
          >
            {item.label} <ArrowUpRight className="size-4" aria-hidden="true" />
          </Link>
        ))}
      </nav>
      <div className="mt-10">
        <CatalogBrowser category={category.data} />
      </div>
    </main>
  );
}

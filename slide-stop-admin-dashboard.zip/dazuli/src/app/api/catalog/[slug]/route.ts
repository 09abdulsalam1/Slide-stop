// @polsia:user-owned — public read-only product detail route.
import 'server-only';

import { NextResponse } from 'next/server';
import { toCatalogProduct } from '@/lib/business/catalog';
import { CatalogProductResponse } from '@/lib/contracts/catalog';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;
    const product = await prisma.product.findUnique({ where: { slug } });
    if (!product) {
      return NextResponse.json({ error: 'Product unavailable' }, { status: 404 });
    }

    return NextResponse.json(CatalogProductResponse.parse({ item: toCatalogProduct(product) }));
  } catch {
    return NextResponse.json({ error: 'Catalog unavailable' }, { status: 500 });
  }
}

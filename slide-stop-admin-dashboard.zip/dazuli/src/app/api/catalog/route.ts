// @polsia:user-owned — public read-only catalog route.
import 'server-only';

import { NextResponse } from 'next/server';
import { toCatalogProduct } from '@/lib/business/catalog';
import { CatalogCategory, CatalogList } from '@/lib/contracts/catalog';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const categoryValue = new URL(request.url).searchParams.get('category');
    const category = categoryValue ? CatalogCategory.safeParse(categoryValue) : null;
    if (categoryValue && !category?.success) {
      return NextResponse.json({ error: 'Unknown catalog category' }, { status: 400 });
    }

    const products = await prisma.product.findMany({
      where: category?.success ? { category: category.data } : undefined,
      orderBy: [{ category: 'asc' }, { name: 'asc' }],
    });
    const payload = CatalogList.parse({ items: products.map(toCatalogProduct) });
    return NextResponse.json(payload);
  } catch {
    return NextResponse.json({ error: 'Catalog unavailable' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { adminCookieOptions, createSessionToken, isAdminRequest, validAdminPassword } from '@/lib/admin/auth';

export async function GET() { return NextResponse.json({ authenticated: await isAdminRequest() }); }
export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (typeof body.password !== 'string' || body.password.length > 200 || !validAdminPassword(body.password)) {
      return NextResponse.json({ error: 'Invalid password' }, { status: 401 });
    }
    const response = NextResponse.json({ authenticated: true });
    response.cookies.set(adminCookieOptions.name, createSessionToken(), adminCookieOptions);
    return response;
  } catch (error) {
    if (error instanceof SyntaxError) return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
    return NextResponse.json({ error: 'Admin authentication is not configured. Set the admin environment variables.' }, { status: 503 });
  }
}
export async function DELETE() {
  const response = NextResponse.json({ authenticated: false });
  response.cookies.set(adminCookieOptions.name, '', { ...adminCookieOptions, maxAge: 0 });
  return response;
}

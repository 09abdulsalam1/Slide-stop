import { NextResponse } from 'next/server';
import { isAdminRequest } from '@/lib/admin/auth';
import { prisma } from '@/lib/db';
import { z } from 'zod';
const input = z.object({ name:z.string().trim().min(2).max(120), category:z.enum(['footwear','handbags','socks','accessories']), description:z.string().max(2000).optional().default(''), imageUrl:z.string().max(500).optional().default(''), priceGhs:z.number().finite().min(0).max(10000000), sizes:z.array(z.string()).max(40), colors:z.array(z.string()).max(40), stockQuantity:z.number().int().min(0).max(1000000), discountPercent:z.number().int().min(0).max(90), salePriceGhs:z.number().finite().min(0).max(10000000).nullable().optional() });
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}) {
 if(!await isAdminRequest()) return NextResponse.json({error:'Unauthorized'},{status:401});
 const {id}=await params; const parsed=input.safeParse(await request.json()); if(!parsed.success) return NextResponse.json({error:'Invalid product fields'},{status:400});
 try { const v=parsed.data; const sale=v.salePriceGhs==null?null:Math.round(v.salePriceGhs*100); if(sale!==null&&sale>Math.round(v.priceGhs*100)) return NextResponse.json({error:'Sale price must not exceed regular price'},{status:400}); const item=await prisma.product.update({where:{id},data:{name:v.name,category:v.category,description:v.description||null,imageUrl:v.imageUrl||null,priceInMinorUnits:Math.round(v.priceGhs*100),currency:'GHS',availableSizes:v.sizes,availableColors:v.colors,stockQuantity:v.stockQuantity,discountPercent:v.discountPercent,salePriceInMinorUnits:sale,stockStatus:v.stockQuantity>0?(v.stockQuantity<=5?'low_stock':'in_stock'):'out_of_stock'}}); return NextResponse.json({item}); }
 catch{return NextResponse.json({error:'Product not found or database unavailable'},{status:404});}
}
export async function DELETE(_request:Request,{params}:{params:Promise<{id:string}>}) { if(!await isAdminRequest()) return NextResponse.json({error:'Unauthorized'},{status:401}); try{const {id}=await params; await prisma.product.delete({where:{id}}); return NextResponse.json({ok:true});}catch{return NextResponse.json({error:'Could not delete product'},{status:400});} }

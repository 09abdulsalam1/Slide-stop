import { NextResponse } from 'next/server';
import { isAdminRequest } from '@/lib/admin/auth';
import { prisma } from '@/lib/db';
import { z } from 'zod';

export const dynamic = 'force-dynamic';
const productInput = z.object({
  name: z.string().trim().min(2).max(120), category: z.enum(['footwear','handbags','socks','accessories']),
  description: z.string().max(2000).optional().default(''), imageUrl: z.string().max(500).optional().default(''),
  priceGhs: z.number().finite().min(0).max(10000000), sizes: z.array(z.string().trim().min(1).max(30)).max(40),
  colors: z.array(z.string().trim().min(1).max(40)).max(40), stockQuantity: z.number().int().min(0).max(1000000),
  discountPercent: z.number().int().min(0).max(90), salePriceGhs: z.number().finite().min(0).max(10000000).nullable().optional(),
});
const slugify = (s: string) => s.toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,100) || 'product';
export async function GET() {
  if (!await isAdminRequest()) return NextResponse.json({ error:'Unauthorized' }, { status:401 });
  try { const products = await prisma.product.findMany({ orderBy:{ updatedAt:'desc' } }); return NextResponse.json({ items: products }); }
  catch { return NextResponse.json({ error:'Products database unavailable. Run the database migration first.' }, { status:503 }); }
}
export async function POST(request: Request) {
  if (!await isAdminRequest()) return NextResponse.json({ error:'Unauthorized' }, { status:401 });
  try {
    const parsed = productInput.safeParse(await request.json());
    if (!parsed.success) return NextResponse.json({ error:'Check required fields and values.' }, { status:400 });
    const v = parsed.data; const base = slugify(v.name); let slug = base; let i=2;
    while (await prisma.product.findUnique({ where:{ slug } })) slug = `${base}-${i++}`;
    const salePrice = v.salePriceGhs == null ? null : Math.round(v.salePriceGhs * 100);
    if (salePrice !== null && salePrice > Math.round(v.priceGhs * 100)) return NextResponse.json({ error:'Sale price must not exceed the regular price.' }, { status:400 });
    const product = await prisma.product.create({ data:{ slug, name:v.name, category:v.category, description:v.description || null, imageUrl:v.imageUrl || null, priceInMinorUnits:Math.round(v.priceGhs*100), currency:'GHS', availableSizes:v.sizes, availableColors:v.colors, stockQuantity:v.stockQuantity, discountPercent:v.discountPercent, salePriceInMinorUnits:salePrice, stockStatus:v.stockQuantity > 0 ? (v.stockQuantity <= 5 ? 'low_stock' : 'in_stock') : 'out_of_stock' } });
    return NextResponse.json({ item:product }, { status:201 });
  } catch { return NextResponse.json({ error:'Could not save product. Check database connection and migration.' }, { status:503 }); }
}

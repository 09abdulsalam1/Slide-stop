import { NextResponse } from 'next/server';
import { randomUUID } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { isAdminRequest } from '@/lib/admin/auth';
export const runtime = 'nodejs';
const allowed = new Map([['image/jpeg','jpg'],['image/png','png'],['image/webp','webp'],['image/avif','avif']]);
export async function POST(request:Request) {
 if(!await isAdminRequest()) return NextResponse.json({error:'Unauthorized'},{status:401});
 try { const form=await request.formData(); const file=form.get('file'); if(!(file instanceof File)) return NextResponse.json({error:'Choose an image file'},{status:400}); const ext=allowed.get(file.type); if(!ext) return NextResponse.json({error:'Use JPG, PNG, WebP, or AVIF images'},{status:415}); if(file.size>5*1024*1024) return NextResponse.json({error:'Maximum image size is 5 MB'},{status:413}); const bytes=Buffer.from(await file.arrayBuffer()); const valid=(file.type==='image/jpeg'&&bytes[0]===0xff&&bytes[1]===0xd8)||(file.type==='image/png'&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))||(file.type==='image/webp'&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')||(file.type==='image/avif'&&bytes.toString('ascii',4,12).includes('ftypavif')); if(!valid) return NextResponse.json({error:'File contents do not match an allowed image type'},{status:415}); const dir=path.join(process.cwd(),'public','uploads'); await mkdir(dir,{recursive:true}); const filename=`${randomUUID()}.${ext}`; await writeFile(path.join(dir,filename),bytes,{flag:'wx',mode:0o644}); return NextResponse.json({url:`/uploads/${filename}`},{status:201}); }
 catch{return NextResponse.json({error:'Image upload failed'},{status:500});}
}

import { NextResponse } from 'next/server';
import { z } from 'zod';
import { isAdminRequest } from '@/lib/admin/auth';
import { prisma } from '@/lib/db';
const bodySchema=z.object({status:z.enum(['pending','confirmed','processing','shipped','delivered','cancelled'])});
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}){if(!await isAdminRequest())return NextResponse.json({error:'Unauthorized'},{status:401});const body=bodySchema.safeParse(await request.json());if(!body.success)return NextResponse.json({error:'Invalid order status'},{status:400});try{const {id}=await params;const item=await prisma.storeOrder.update({where:{id},data:{status:body.data.status}});return NextResponse.json({item});}catch{return NextResponse.json({error:'Order not found'},{status:404});}}

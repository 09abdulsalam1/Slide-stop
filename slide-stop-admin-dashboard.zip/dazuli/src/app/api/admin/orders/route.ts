import { NextResponse } from 'next/server';
import { isAdminRequest } from '@/lib/admin/auth';
import { prisma } from '@/lib/db';
export const dynamic='force-dynamic';
export async function GET(){ if(!await isAdminRequest()) return NextResponse.json({error:'Unauthorized'},{status:401}); try{const orders=await prisma.storeOrder.findMany({include:{items:true},orderBy:{createdAt:'desc'},take:300}); return NextResponse.json({items:orders});}catch{return NextResponse.json({error:'Orders database unavailable. Run the database migration first.'},{status:503});} }

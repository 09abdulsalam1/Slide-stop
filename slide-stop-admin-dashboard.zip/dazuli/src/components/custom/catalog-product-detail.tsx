// @polsia:user-owned — client island for a public product detail read.
'use client';

import { ArrowLeft, ImageOff } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { catalogCategories } from '@/lib/business/catalog';
import { type CatalogProduct, CatalogProductResponse } from '@/lib/contracts/catalog';
import { AddToCart } from '@/components/custom/order-actions';

function displayPrice(product: CatalogProduct) {
  if (product.priceInMinorUnits === null || !product.currency) return 'Unavailable';
  const effective = product.salePriceInMinorUnits ?? (product.discountPercent > 0 ? Math.round(product.priceInMinorUnits * (100 - product.discountPercent) / 100) : product.priceInMinorUnits);
  try {
    return new Intl.NumberFormat('en-GH', {
      style: 'currency',
      currency: product.currency,
      maximumFractionDigits: 2,
    }).format(effective / 100);
  } catch {
    return 'Unavailable';
  }
}

function displayStock(status: string | null, quantity?: number) {
  if (typeof quantity === 'number') return quantity <= 0 ? 'Out of stock' : quantity <= 5 ? `Low stock (${quantity} left)` : 'In stock';
  if (!status?.trim()) return 'Unavailable';
  const labels: Record<string, string> = {
    in_stock: 'In stock',
    out_of_stock: 'Out of stock',
    low_stock: 'Low stock',
  };
  return labels[status] ?? status;
}

function categoryLabel(category: string) {
  return catalogCategories.find((item) => item.slug === category)?.label ?? category;
}

function DetailField({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-t border-border pt-4">
      <dt className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-2 text-base">{value}</dd>
    </div>
  );
}

export function CatalogProductDetail({ slug }: { slug: string }) {
  const [product, setProduct] = useState<CatalogProduct | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'unavailable'>('loading');

  useEffect(() => {
    let mounted = true;
    apiFetch(`/api/catalog/${encodeURIComponent(slug)}`, { schema: CatalogProductResponse })
      .then((payload) => {
        if (!mounted) return;
        setProduct(payload.item);
        setStatus('ready');
      })
      .catch(() => {
        if (mounted) setStatus('unavailable');
      });
    return () => {
      mounted = false;
    };
  }, [slug]);

  if (status === 'loading') {
    return (
      <p className="rounded-2xl border border-border bg-card p-8 text-muted-foreground">
        Loading supplied product details…
      </p>
    );
  }

  if (status === 'unavailable' || !product) {
    return (
      <Card className="rounded-3xl border-dashed shadow-none">
        <CardContent className="p-8 sm:p-12">
          <h1 className="font-display text-3xl tracking-[-0.04em]">Product details unavailable</h1>
          <p className="mt-3 max-w-xl leading-7 text-muted-foreground">
            This product is not present in Slide Stop&apos;s supplied catalog data, so no product
            information has been invented.
          </p>
          <Button asChild variant="outline" className="mt-7 rounded-full">
            <Link href="/catalog">
              <ArrowLeft /> Back to catalog
            </Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1.05fr_.95fr] lg:items-start">
      <div className="relative aspect-square overflow-hidden rounded-3xl border border-border bg-muted">
        {product.imageUrl ? (
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            sizes="(min-width: 1024px) 55vw, 100vw"
            className="object-cover"
            unoptimized
          />
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground">
            <ImageOff className="size-10" aria-hidden="true" />
            <span>Image unavailable</span>
          </div>
        )}
      </div>
      <div>
        <Badge
          variant="outline"
          className="rounded-full text-[0.65rem] uppercase tracking-[0.16em]"
        >
          {categoryLabel(product.category)}
        </Badge>
        <h1 className="mt-5 font-display text-5xl leading-none tracking-[-0.06em] sm:text-6xl">
          {product.name}
        </h1>
        <p className="mt-5 text-lg leading-8 text-muted-foreground">
          {product.description ?? 'Description unavailable'}
        </p>
        <dl className="mt-10 grid gap-5">
          <DetailField label="Price" value={`${displayPrice(product)}${product.discountPercent > 0 ? ` (${product.discountPercent}% off)` : ''}`} />
          {product.availableColors.length > 0 && <DetailField label="Available colors" value={product.availableColors.join(', ')} />}
          <DetailField
            label="Available sizes"
            value={
              product.availableSizes.length > 0 ? product.availableSizes.join(', ') : 'Unavailable'
            }
          />
          <DetailField label="Stock status" value={displayStock(product.stockStatus, product.stockQuantity)} />
        </dl>
        <AddToCart product={product} />
        <Button asChild variant="outline" className="mt-6 rounded-full">
          <Link href={`/catalog/${product.category}`}>
            <ArrowLeft /> More {categoryLabel(product.category).toLowerCase()}
          </Link>
        </Button>
      </div>
    </div>
  );
}

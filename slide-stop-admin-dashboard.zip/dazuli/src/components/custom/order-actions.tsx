'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ShoppingBag, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { CatalogProduct } from '@/lib/contracts/catalog';
import { CART_STORAGE_KEY, type CartLine, orderMessage } from '@/lib/business/cart';

function readCart(): CartLine[] {
  try { const value = localStorage.getItem(CART_STORAGE_KEY); return value ? JSON.parse(value) as CartLine[] : []; }
  catch { return []; }
}
function whatsappUrl(message: string) {
  const phone = process.env.NEXT_PUBLIC_Slide Stop_WHATSAPP_NUMBER?.replace(/\D/g, '');
  return phone ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}` : `https://wa.me/?text=${encodeURIComponent(message)}`;
}

export function AddToCart({ product }: { product: CatalogProduct }) {
  const router = useRouter();
  const [size, setSize] = useState(product.availableSizes[0] ?? '');
  const [added, setAdded] = useState(false);
  const canOrder = product.priceInMinorUnits !== null && product.stockStatus !== 'out_of_stock';
  function add() {
    const cart = readCart();
    const index = cart.findIndex((line) => line.product.id === product.id && line.size === size);
    if (index >= 0) cart[index]!.quantity += 1;
    else cart.push({ product, quantity: 1, size });
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    setAdded(true);
  }
  function orderWhatsApp() {
    const line: CartLine = { product, quantity: 1, size };
    const message = `Hello Slide Stop! I'd like to order:\n\n${product.name}${size ? ` (Size: ${size})` : ''} × 1\nPrice: ${product.priceInMinorUnits === null ? 'Please confirm price' : new Intl.NumberFormat('en-GH', { style: 'currency', currency: product.currency ?? 'GHS' }).format(product.priceInMinorUnits / 100)}\nPayment: Cash on delivery\n\nPlease confirm availability, delivery fee, and how I can provide my delivery details.`;
    window.open(whatsappUrl(message), '_blank', 'noopener,noreferrer');
  }
  return <div className="mt-8 space-y-3">
    {product.availableSizes.length > 0 && <label className="block text-sm font-medium">Choose size<select className="mt-2 block w-full rounded-xl border border-border bg-background px-4 py-3" value={size} onChange={(event) => setSize(event.target.value)}>{product.availableSizes.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>}
    <Button className="w-full rounded-full" disabled={!canOrder} onClick={add}><ShoppingBag className="mr-2 size-4"/>{added ? 'Add another' : 'Add to bag'}</Button>
    {added && <div role="status" className="rounded-xl border border-border p-3 text-sm">Added to your bag. <button className="font-semibold text-primary underline" onClick={() => router.push('/checkout')}>Go to checkout</button></div>}
    <Button variant="outline" className="w-full rounded-full" disabled={!canOrder} onClick={orderWhatsApp}><MessageCircle className="mr-2 size-4"/>Order this on WhatsApp</Button>
    <p className="text-xs leading-5 text-muted-foreground">Cash on delivery. We’ll confirm availability, delivery fee, and delivery details before dispatch.</p>
  </div>;
}

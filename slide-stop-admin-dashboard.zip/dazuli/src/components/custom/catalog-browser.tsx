// @polsia:user-owned — client island for public catalog reads.
'use client';

import { ArrowUpRight, ImageOff, PackageOpen } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { catalogCategories } from '@/lib/business/catalog';
import { type CatalogCategory, CatalogList, type CatalogProduct } from '@/lib/contracts/catalog';

function formatPrice(product: CatalogProduct) {
  if (product.priceInMinorUnits === null || !product.currency) return 'Price unavailable';
  const effective = product.salePriceInMinorUnits ?? (product.discountPercent > 0 ? Math.round(product.priceInMinorUnits * (100 - product.discountPercent) / 100) : product.priceInMinorUnits);
  try {
    return new Intl.NumberFormat('en-GH', {
      style: 'currency',
      currency: product.currency,
      maximumFractionDigits: 2,
    }).format(effective / 100);
  } catch {
    return 'Price unavailable';
  }
}

function categoryLabel(category: string) {
  return catalogCategories.find((item) => item.slug === category)?.label ?? category;
}

export function CatalogBrowser({ category }: { category?: CatalogCategory }) {
  const [items, setItems] = useState<CatalogProduct[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');

  useEffect(() => {
    let mounted = true;
    const query = category ? `?category=${encodeURIComponent(category)}` : '';
    setStatus('loading');
    apiFetch(`/api/catalog${query}`, { schema: CatalogList })
      .then((payload) => {
        if (!mounted) return;
        setItems(payload.items);
        setStatus('ready');
      })
      .catch(() => {
        if (mounted) setStatus('error');
      });
    return () => {
      mounted = false;
    };
  }, [category]);

  if (status === 'loading') {
    return (
      <p className="rounded-2xl border border-border bg-card p-8 text-muted-foreground">
        Loading the supplied catalog…
      </p>
    );
  }

  if (status === 'error') {
    return (
      <p
        role="alert"
        className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-destructive"
      >
        The catalog is unavailable right now. Please try again later.
      </p>
    );
  }

  if (items.length === 0) {
    return (
      <div className="rounded-3xl border border-dashed border-border bg-card p-10 text-center sm:p-16">
        <PackageOpen className="mx-auto size-10 text-primary" aria-hidden="true" />
        <h2 className="mt-5 font-display text-3xl tracking-[-0.04em]">No supplied products yet.</h2>
        <p className="mx-auto mt-3 max-w-lg leading-7 text-muted-foreground">
          Slide Stop will show products here when canonical product data is supplied. Nothing is
          invented in the meantime.
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((product) => (
        <Link
          key={product.id}
          href={`/catalog/product/${encodeURIComponent(product.slug)}`}
          className="group block"
        >
          <Card className="h-full overflow-hidden rounded-3xl border-border bg-card shadow-none transition-transform duration-300 ease-out group-hover:-translate-y-1">
            <div className="relative aspect-[4/3] overflow-hidden bg-muted">
              {product.imageUrl ? (
                <Image
                  src={product.imageUrl}
                  alt={product.name}
                  fill
                  sizes="(min-width: 1024px) 30vw, (min-width: 640px) 45vw, 100vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  unoptimized
                />
              ) : (
                <div className="flex h-full flex-col items-center justify-center gap-2 text-muted-foreground">
                  <ImageOff className="size-7" aria-hidden="true" />
                  <span className="text-sm">Image unavailable</span>
                </div>
              )}
            </div>
            <CardContent className="flex min-h-40 flex-col justify-between gap-5 p-6">
              <div>
                <Badge
                  variant="outline"
                  className="rounded-full text-[0.65rem] uppercase tracking-[0.16em]"
                >
                  {categoryLabel(product.category)}
                </Badge>
                <h2 className="mt-4 font-display text-2xl tracking-[-0.04em]">{product.name}</h2>
              </div>
              <div className="flex items-center justify-between gap-3 text-sm">
                <span className="text-muted-foreground">{formatPrice(product)}{(product.salePriceInMinorUnits !== null || product.discountPercent > 0) && product.priceInMinorUnits !== null ? <span className="ml-2 text-xs line-through opacity-60">{new Intl.NumberFormat('en-GH', { style: 'currency', currency: product.currency ?? 'GHS', maximumFractionDigits: 2 }).format(product.priceInMinorUnits / 100)}</span> : null}</span>
                <span className="inline-flex items-center gap-1 font-semibold text-primary">
                  View details <ArrowUpRight className="size-4" aria-hidden="true" />
                </span>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}

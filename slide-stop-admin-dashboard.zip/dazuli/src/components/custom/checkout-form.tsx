'use client';

import { useEffect, useMemo, useState, type FormEvent } from 'react';
import Link from 'next/link';
import { ArrowLeft, Minus, Plus, Trash2, MessageCircle, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CART_STORAGE_KEY, formatGhs, orderMessage, type CartLine } from '@/lib/business/cart';

type Customer = { name: string; phone: string; address: string; notes: string };
const emptyCustomer: Customer = { name: '', phone: '', address: '', notes: '' };
function whatsappUrl(message: string) {
  const phone = process.env.NEXT_PUBLIC_Slide Stop_WHATSAPP_NUMBER?.replace(/\D/g, '');
  return phone ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}` : `https://wa.me/?text=${encodeURIComponent(message)}`;
}
function money(line: CartLine) { const base = line.product.priceInMinorUnits; const unit = base === null ? null : (line.product.salePriceInMinorUnits ?? (line.product.discountPercent > 0 ? Math.round(base * (100 - line.product.discountPercent) / 100) : base)); return unit === null ? 'Price unavailable' : formatGhs(unit * line.quantity, line.product.currency); }

export function CheckoutForm() {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [customer, setCustomer] = useState<Customer>(emptyCustomer);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [placingOrder, setPlacingOrder] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [savedOrder, setSavedOrder] = useState(false);
  useEffect(() => { try { const raw = localStorage.getItem(CART_STORAGE_KEY); if (raw) setCart(JSON.parse(raw) as CartLine[]); } catch { setCart([]); } }, []);
  const total = useMemo(() => cart.reduce((sum, line) => { const base = line.product.priceInMinorUnits ?? 0; const unit = line.product.salePriceInMinorUnits ?? (line.product.discountPercent > 0 ? Math.round(base * (100 - line.product.discountPercent) / 100) : base); return sum + unit * line.quantity; }, 0), [cart]);
  function persist(next: CartLine[]) { setCart(next); localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(next)); }
  function quantity(index: number, amount: number) { const next = cart.map((line, i) => i === index ? { ...line, quantity: line.quantity + amount } : line).filter((line) => line.quantity > 0); persist(next); }
  function update(field: keyof Customer, value: string) { setCustomer((current) => ({ ...current, [field]: value })); }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    if (!cart.length) { setError('Your bag is empty. Add a product before checkout.'); return; }
    if (cart.some((line) => line.product.priceInMinorUnits === null)) { setError('One or more products have no price yet. Please contact Slide Stop before ordering.'); return; }
    setPlacingOrder(true);
    try {
      const response = await fetch('/api/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ customerName: customer.name, phone: customer.phone, deliveryAddress: customer.address, deliveryNotes: customer.notes, items: cart.map((line) => ({ productId: line.product.id, quantity: line.quantity, size: line.size || undefined })) }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not place order');
      setOrderNumber(data.orderNumber); setSavedOrder(true); setSubmitted(true);
      localStorage.removeItem(CART_STORAGE_KEY);
    } catch (e) {
      setError(`${e instanceof Error ? e.message : 'Could not place order'}. You can still send your order request through WhatsApp for manual confirmation.`);
      setSubmitted(true); setSavedOrder(false);
    } finally { setPlacingOrder(false); }
  }
  function sendWhatsApp() { const message = `${orderMessage(cart, customer)}${orderNumber ? `\n\nSlide Stop website order reference: ${orderNumber}` : ''}`; window.open(whatsappUrl(message), '_blank', 'noopener,noreferrer'); }
  if (submitted) return <section className="mx-auto max-w-2xl rounded-3xl border border-border bg-card p-7 sm:p-10">
    <div className="mb-5 flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary"><ShoppingBag/></div>
    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">{savedOrder ? 'Order received' : 'WhatsApp fallback'}</p>
    <h1 className="mt-3 font-display text-4xl tracking-[-0.05em]">{savedOrder ? 'Your order is in the system.' : 'Send your order request.'}</h1>
    <p className="mt-4 leading-7 text-muted-foreground">{savedOrder ? `Order reference: ${orderNumber}. Slide Stop can now see this order in the admin dashboard. Send the details on WhatsApp too if you want to confirm delivery arrangements.` : 'The website could not save this order. You can still send a WhatsApp request so Slide Stop can confirm stock, delivery fee and timing. Please wait for confirmation.'} Payment is due on delivery; nothing is charged online.</p>
    <div className="my-6 rounded-2xl bg-muted/50 p-5 text-sm"><p><strong>Customer:</strong> {customer.name}</p><p className="mt-1"><strong>Phone:</strong> {customer.phone}</p><p className="mt-1"><strong>Delivery:</strong> {customer.address}</p><p className="mt-3 text-base font-semibold">Items subtotal: {formatGhs(total, 'GHS')}</p><p className="mt-1 text-muted-foreground">Delivery fee is confirmed separately.</p></div>
    <Button className="w-full rounded-full" onClick={sendWhatsApp}><MessageCircle className="mr-2 size-4"/>{savedOrder ? 'Also confirm on WhatsApp' : 'Send order on WhatsApp'}</Button>
    <Button variant="outline" className="mt-3 w-full rounded-full" onClick={() => setSubmitted(false)}>Back to edit details</Button>
    {error && <p role="alert" className="mb-3 mt-4 rounded-xl bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
    <p className="mt-4 text-xs leading-5 text-muted-foreground">{savedOrder ? 'Your order is saved, but Slide Stop must still confirm delivery details.' : 'The website did not save this order. A WhatsApp request needs to be sent and confirmed separately.'}</p>
  </section>;
  return <div className="grid gap-10 lg:grid-cols-[1fr_.85fr] lg:items-start">
    <form onSubmit={submit} className="space-y-6 rounded-3xl border border-border bg-card p-6 sm:p-8">
      <div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Cash on delivery</p><h1 className="mt-3 font-display text-4xl tracking-[-0.05em] sm:text-5xl">Checkout</h1><p className="mt-3 leading-7 text-muted-foreground">Enter your delivery details. Pay when your order arrives.</p></div>
      <label className="block text-sm font-medium">Full name<input required autoComplete="name" value={customer.name} onChange={(e) => update('name', e.target.value)} className="mt-2 block w-full rounded-xl border border-border bg-background px-4 py-3" placeholder="Your full name"/></label>
      <label className="block text-sm font-medium">Phone number<input required type="tel" autoComplete="tel" value={customer.phone} onChange={(e) => update('phone', e.target.value)} className="mt-2 block w-full rounded-xl border border-border bg-background px-4 py-3" placeholder="e.g. 024 000 0000"/></label>
      <label className="block text-sm font-medium">Delivery address<input required autoComplete="street-address" value={customer.address} onChange={(e) => update('address', e.target.value)} className="mt-2 block w-full rounded-xl border border-border bg-background px-4 py-3" placeholder="Area, street, landmark, city"/></label>
      <label className="block text-sm font-medium">Order notes <span className="font-normal text-muted-foreground">(optional)</span><textarea value={customer.notes} onChange={(e) => update('notes', e.target.value)} rows={3} className="mt-2 block w-full rounded-xl border border-border bg-background px-4 py-3" placeholder="Preferred delivery time or extra directions"/></label>
      <div className="rounded-xl border border-border p-4"><p className="font-semibold">Payment method</p><p className="mt-1 text-sm text-muted-foreground">Pay on delivery — no online payment required.</p></div>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <Button type="submit" disabled={placingOrder} className="w-full rounded-full">{placingOrder ? 'Placing order…' : 'Place order · Pay on delivery'}</Button>
      <p className="text-xs leading-5 text-muted-foreground">By continuing, you agree that Slide Stop may use these details to arrange this order. Avoid adding sensitive personal information to order notes.</p>
    </form>
    <aside className="rounded-3xl border border-border p-6 sm:p-8"><h2 className="font-display text-2xl tracking-[-0.04em]">Your bag ({cart.reduce((sum, line) => sum + line.quantity, 0)})</h2>
      {!cart.length ? <div className="py-10 text-center"><ShoppingBag className="mx-auto size-8 text-muted-foreground"/><p className="mt-4 text-muted-foreground">Your bag is empty.</p><Button asChild className="mt-5 rounded-full"><Link href="/catalog">Browse products</Link></Button></div> : <>
        <div className="mt-5 divide-y divide-border">{cart.map((line, index) => <div key={`${line.product.id}-${line.size}`} className="py-5"><div className="flex justify-between gap-3"><div><p className="font-semibold">{line.product.name}</p><p className="mt-1 text-sm text-muted-foreground">{line.size ? `Size ${line.size} · ` : ''}{money(line)}</p></div><button aria-label={`Remove ${line.product.name}`} onClick={() => { const next = cart.filter((_, i) => i !== index); persist(next); }} className="text-muted-foreground hover:text-destructive"><Trash2 className="size-4"/></button></div><div className="mt-3 inline-flex items-center gap-3 rounded-full border border-border px-2 py-1"><button aria-label="Decrease quantity" onClick={() => quantity(index, -1)} className="rounded-full p-1 hover:bg-muted"><Minus className="size-3"/></button><span className="min-w-4 text-center text-sm">{line.quantity}</span><button aria-label="Increase quantity" onClick={() => quantity(index, 1)} className="rounded-full p-1 hover:bg-muted"><Plus className="size-3"/></button></div></div>)}</div>
        <div className="border-t border-border pt-5"><div className="flex justify-between text-lg font-semibold"><span>Subtotal</span><span>{formatGhs(total, 'GHS')}</span></div><p className="mt-2 text-sm leading-6 text-muted-foreground">Delivery is not included and will be confirmed before dispatch.</p><Link href="/catalog" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-primary"><ArrowLeft className="size-4"/>Continue shopping</Link></div>
      </>}
    </aside>
  </div>;
}

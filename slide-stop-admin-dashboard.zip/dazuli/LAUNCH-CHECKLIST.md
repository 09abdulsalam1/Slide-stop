# Slide Stop launch checklist

## Order flow included
- Product detail pages let customers add a product (and size, when sizes exist) to a browser-persisted bag.
- `/checkout` collects customer name, phone, delivery address, optional delivery notes, and quantity changes.
- Payment is cash on delivery. No card or Mobile Money payment is taken.
- Review step prepares the order summary and lets the customer send it to Slide Stop over WhatsApp.
- Product pages also offer a direct WhatsApp order action.

## Required before launch
1. Set `NEXT_PUBLIC_Slide Stop_WHATSAPP_NUMBER` to the business WhatsApp number using international digits only (Ghana format starts with `233`).
2. Add and verify real product records, prices in pesewas, stock status, sizes, and product photos.
3. Confirm delivery coverage, delivery fees, and cash-on-delivery rules.
4. Run `npm run typecheck`, `npm test`, and `npm run build`.
5. Deploy to a hosting provider and connect the production domain.
6. Test on a phone: add product, change quantity, complete checkout, and confirm WhatsApp opens with the correct order details.

## Important order-handling note
The checkout is a customer-facing order request flow, not an order-management backend. It prepares the details in the browser and sends them to the business via WhatsApp when the customer taps the send button. Orders are not stored in a server database and are not considered placed until the customer sends the WhatsApp message and Slide Stop confirms availability, delivery fee, and timing. Add a database-backed order API/admin view if you want to receive website orders without relying on WhatsApp.

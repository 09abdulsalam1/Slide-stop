// @polsia:user-owned — browser checks run against the app started by verify.sh.
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  use: {
    baseURL: process.env.BASE_URL ?? 'http://127.0.0.1:3000',
  },
});

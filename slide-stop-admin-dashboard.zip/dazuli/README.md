# Slide Stop — online footwear & accessories store

Slide Stop is a responsive storefront starter for a Ghana-focused fashion business. It includes a branded landing page, category navigation, a catalog UI, SEO metadata, and a Next.js API layer for product records.

## Run locally

Requirements: Node.js 20.18.1 or newer and npm.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build

```bash
npm run build
npm run start
```

## Admin dashboard (new)

- Private `/admin` dashboard with password login, product CRUD, image uploads, size/color variations, stock counts, sale pricing/discounts, and order status management.
- `POST /api/orders` saves cash-on-delivery website orders to PostgreSQL and checks/decrements inventory.
- Configure `Slide Stop_ADMIN_PASSWORD`, `ADMIN_SESSION_SECRET`, and `DATABASE_URL`; then follow [`ADMIN-SETUP.md`](./ADMIN-SETUP.md) to migrate the schema and test.
- Local filesystem photo uploads are for development only; production hosting needs durable object storage and additional operational safeguards.

## Current functionality

- Responsive home page with collection categories and delivery messaging.
- Catalog and category pages at `/catalog` and `/catalog/[category]`.
- Product display reads from the app's catalog API. No products are fabricated; until real product records are added, the catalog will show an empty state.
- Order CTA currently opens an email draft to `Slide Stop@polsia.app`; replace this with the business's real email or WhatsApp order contact before launch.
- The project does not yet include a live checkout/payment flow, inventory management, or seeded product listings.

## Before launch

1. Add real product names, descriptions, photos, prices, sizes, and stock status to the catalog data source.
2. Replace `Slide Stop@polsia.app` in `src/app/(setup)/page.tsx` with the business's actual order contact.
3. Configure the production app URL and database environment variables on your hosting provider.
4. Set up and test a real checkout/payment workflow if you want customers to pay online.
5. Deploy the Next.js app to a Node-compatible host (for example, Vercel) and connect your domain.

## Useful commands

```bash
npm run typecheck
npm run lint
npm test
npm run build
```
